Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v12.1 (Version 12.600.0.14)

Date    :    Tue Apr 21 15:48:55 2020
Project :    E:\Github_Repos\SF2_Eth_FFT\FFT_Accelerator
